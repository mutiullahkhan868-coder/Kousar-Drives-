@echo off
title Kousar Drives - Starting...
cd /d "%~dp0backend"

where node >nul 2>nul
if errorlevel 1 (
    echo.
    echo ============================================================
    echo   Node.js is not installed on this computer.
    echo   Please install it first: https://nodejs.org  (choose LTS)
    echo   Then double-click this file again.
    echo ============================================================
    echo.
    pause
    exit /b
)

if not exist ".env" (
    copy ".env.example" ".env" >nul
)

if not exist "node_modules" (
    echo Setting up Kousar Drives for the first time - this may take a minute...
    call npm install
    if errorlevel 1 (
        echo.
        echo Something went wrong installing dependencies. Check the messages above.
        pause
        exit /b
    )
)

echo.
echo Starting Kousar Drives...
echo Once you see "running on port 3000" below, your browser will open automatically.
echo Keep this window open while you use the app - closing it stops the server.
echo.

start "" http://localhost:3000
call npm start

pause
