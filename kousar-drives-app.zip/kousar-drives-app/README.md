# Kousar Drives

A real, working ride-hailing backend + mobile web app for Haripur — bike rickshaw, car, and Hiace,
with rider-set fares within a min/max range, driver accept/skip, admin-approved driver registration
with document upload, live GPS tracking, and fingerprint login for drivers.

This is real code with a real database, real file uploads, and real-time updates via Socket.io —
not a mockup. It is **not yet deployed anywhere** — you (or someone helping you) need to put it on
a server. See "Deploying for real" below.

## What's actually built right now

- **Rider**: signs up/logs in, sets pickup (GPS or tap the map) and destination (tap the map),
  picks a vehicle, gets a fare range computed from real distance + admin-set rates, drags a slider
  to choose a fare in that range, sends the request, watches for a driver to accept, sees the
  driver's live location on the map.
- **Driver**: registers with name, phone, password, CNIC number, CNIC photo, profile photo,
  driving license photo, vehicle document photo, vehicle type, and CC. Account starts `pending`
  until an admin approves it. Once approved: goes online, receives ride offers in real time,
  Accept or Skip only (no counter-offer), shares live location while on a trip, can set up
  fingerprint (biometric) login for faster future logins.
- **Admin**: logs in separately, sees every driver registration with links to view their uploaded
  documents, approves/blocks drivers, edits the base fare + min/max per-km rate for each vehicle
  type, views recent rides.
- **Maps**: OpenStreetMap via Leaflet — free, no API key, no credit card, unlike Google Maps.
- **Fare logic**: `fare = baseFare + km × rate`, where `rate` ranges between an admin-set min and
  max per vehicle type. Tune these numbers to real fuel cost + your desired margin per vehicle —
  they're just starting placeholders in `backend/data/store.js`.

## What's intentionally simplified for now (and why)

- **Payments**: cash only. Wiring up JazzCash/Easypaisa requires you to have a registered business
  and a signed merchant agreement with them first — that's paperwork, not code. Once you have that,
  their SDKs plug into the ride-completion flow.
- **Destination search**: you tap the map to set pickup/destination rather than typing an address.
  A text search box (using the free Nominatim geocoding service) can be added on top of this —
  ask if you want that next.
- **Driver-nearby matching**: every online, approved driver of the right vehicle type gets notified
  of a new ride — there's no radius/distance filtering yet. Fine for a single-town pilot; worth
  adding once you have enough drivers that blasting everyone gets noisy.
- **Data storage**: a JSON file (`backend/data/db.json`), not a full database server. This is
  genuinely fine for a pilot (hundreds of users) — migrate to Postgres when you outgrow it.

## Running it locally (to test before deploying)

**Windows shortcut**: just double-click **`Start Kousar Drives.bat`** in this folder. The first
time, it'll install what it needs (takes a minute or two) and then open the app in your browser
automatically. Every time after that, double-clicking it just starts the app. You do still need
[Node.js](https://nodejs.org) installed once — the .bat file will tell you if it's missing and
point you to the download.

**Manual way** (Mac/Linux, or if you prefer typing commands yourself):

You'll need [Node.js](https://nodejs.org) installed (v18 or newer).

```bash
cd backend
cp .env.example .env
npm install
npm start
```

Then open `http://localhost:3000` in your browser. Use the Rider / Driver / Admin tabs to test
each flow. Default admin login is `admin` / `changeme123` (from `.env.example`) — **change this**
before you let anyone else near it.

Fingerprint (WebAuthn) login only works on `localhost` or a real domain with HTTPS — it will not
work if you just open the HTML file directly (`file://`) or over plain HTTP on a non-localhost
address.

## Deploying for real (so it's live for actual riders/drivers in Haripur)

You need somewhere to run the Node.js server continuously. Free options that don't require a
credit card for the base tier:

1. **Render.com** (free web service tier) — connect your GitHub repo, set the root directory to
   `backend`, build command `npm install`, start command `npm start`. Add your `.env` values as
   environment variables in their dashboard.
2. **Railway.app** or **Fly.io** — similar process, generous free/trial tiers.

Steps:
1. Push this project to a GitHub repository.
2. Create an account on one of the above.
3. Point it at the `backend` folder, set environment variables from `.env.example` (use a real
   random `JWT_SECRET`, a real admin password, and set `WEBAUTHN_RP_ID` / `WEBAUTHN_ORIGIN` to your
   real domain once you have one, e.g. `kousardrives.onrender.com`).
4. Once deployed, the same server serves the frontend automatically (it's in `frontend/` and
   served as static files) — no separate hosting needed for the app itself.
5. Share the URL — riders and drivers can open it in their phone browser and "Add to Home Screen"
   to use it like an app, no app store required.

**Important**: the free tiers on these hosts often spin the server down when idle and wake it up
on the next request (a few seconds' delay) — fine for a pilot, worth upgrading to a paid tier once
you have real daily usage.

## Data protection note

You will be handling real CNIC numbers, CNIC photos, and driving licenses. Treat `backend/uploads`
and `backend/data/db.json` as sensitive — they are excluded from version control by `.gitignore` on
purpose. Make sure whatever host you use keeps them private, and think about who on your team can
access the admin panel.

## Turning this into a downloadable APK

I can't compile a signed APK from inside this chat — that needs the Android SDK and Gradle, which
require an internet connection to download (my sandbox here has none). But the app is now set up
as a real installable PWA (icons + manifest + service worker are all in `frontend/`), which makes
turning it into an APK a genuinely quick, free step once it's deployed:

1. **Deploy the app first** (see "Deploying for real" above) so it has a real public URL, e.g.
   `https://kousardrives.onrender.com`. PWABuilder needs to load the live site to package it.
2. Go to **[pwabuilder.com](https://www.pwabuilder.com)**, paste your live URL, click "Start".
3. It'll detect the manifest/icons/service worker automatically. Click the **Android** package
   option, then **Generate Package**.
4. Download the `.apk` (or `.aab` for Play Store) it gives you — that's a real, installable Android
   app your drivers/riders can download and open directly on their phones (they'll need to allow
   "install from unknown sources" once, since it's outside the Play Store).

This takes about 5 minutes once the site is live, costs nothing, and needs no Android Studio setup.
If you eventually want it properly listed on the Google Play Store, the same PWABuilder output can
be submitted there for the one-time $25 developer fee.

## Next steps worth asking for

- A destination search box (typed address instead of map-tap only)
- Wrapping this as an installable native Android app once you have real usage and can afford the
  Play Store fee
- Online payment integration once you have a JazzCash/Easypaisa merchant account
- Distance-based driver matching instead of notifying every online driver
