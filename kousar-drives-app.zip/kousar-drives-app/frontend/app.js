/* ======================= Kousar Drives — frontend app ======================= */
const API = ""; // same-origin. If you host frontend separately, set e.g. "https://api.yourdomain.com"
const HARIPUR_CENTER = [33.9964, 73.2360];

const state = {
  role: "rider",
  riderToken: localStorage.getItem("riderToken") || null,
  driverToken: localStorage.getItem("driverToken") || null,
  adminToken: localStorage.getItem("adminToken") || null,
  riderInfo: JSON.parse(localStorage.getItem("riderInfo") || "null"),
  driverInfo: JSON.parse(localStorage.getItem("driverInfo") || "null"),
};

let socket = null;
function ensureSocket(token) {
  if (!socket) socket = io();
  socket.emit("join", { token });
}

async function api(path, { method = "GET", token, body, isForm = false } = {}) {
  const headers = {};
  if (token) headers["Authorization"] = `Bearer ${token}`;
  if (!isForm) headers["Content-Type"] = "application/json";
  const res = await fetch(API + path, {
    method,
    headers,
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong");
  return data;
}

const view = document.getElementById("view");
function render(html) { view.innerHTML = html; }

/* ---------------- role switching ---------------- */
document.getElementById("roleTabs").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-role]");
  if (!btn) return;
  document.querySelectorAll("#roleTabs button").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  state.role = btn.dataset.role;
  routeTo(state.role);
});

function routeTo(role) {
  if (role === "rider") return state.riderToken ? renderRiderHome() : renderRiderAuth();
  if (role === "driver") return state.driverToken ? renderDriverHome() : renderDriverAuth();
  if (role === "admin") return state.adminToken ? renderAdminHome() : renderAdminAuth();
}

/* =============================== RIDER =============================== */

function renderRiderAuth() {
  render(`
    <div id="msg"></div>
    <div class="card">
      <h3 class="display" style="margin:0 0 10px;font-size:20px;">Rider login</h3>
      <div class="field"><label>PHONE</label><input id="r-phone" placeholder="03xxxxxxxxx"/></div>
      <div class="field"><label>PASSWORD</label><input id="r-pass" type="password"/></div>
      <button class="btn btn-gold" id="r-login-btn">Log in</button>
    </div>
    <div class="card">
      <h3 class="display" style="margin:0 0 10px;font-size:20px;">New here? Sign up</h3>
      <div class="field"><label>NAME</label><input id="r-name"/></div>
      <div class="field"><label>PHONE</label><input id="r-phone2" placeholder="03xxxxxxxxx"/></div>
      <div class="field"><label>PASSWORD</label><input id="r-pass2" type="password"/></div>
      <button class="btn btn-dark" id="r-signup-btn">Create account</button>
    </div>
  `);
  document.getElementById("r-login-btn").onclick = async () => {
    try {
      const data = await api("/api/auth/rider/login", { method: "POST", body: { phone: val("r-phone"), password: val("r-pass") } });
      saveRiderSession(data);
    } catch (e) { showMsg(e.message); }
  };
  document.getElementById("r-signup-btn").onclick = async () => {
    try {
      const data = await api("/api/auth/rider/signup", { method: "POST", body: { name: val("r-name"), phone: val("r-phone2"), password: val("r-pass2") } });
      saveRiderSession(data);
    } catch (e) { showMsg(e.message); }
  };
}
function saveRiderSession(data) {
  state.riderToken = data.token; state.riderInfo = data.rider;
  localStorage.setItem("riderToken", data.token);
  localStorage.setItem("riderInfo", JSON.stringify(data.rider));
  ensureSocket(data.token);
  renderRiderHome();
}

let riderMap, pickupMarker, destMarker, pickMode = "pickup";
let rideState = { pickup: null, dest: null, vehicle: "rickshaw", fare: null, activeRide: null };

function renderRiderHome() {
  render(`
    <div class="muted" style="margin-bottom:10px;">Hi ${state.riderInfo.name} · <button class="link-btn" id="r-logout">Log out</button></div>
    <div id="msg"></div>
    <div id="map"></div>
    <div class="map-controls">
      <button id="mode-pickup" class="active">📍 Tap to set pickup</button>
      <button id="mode-dest">🏁 Tap to set destination</button>
    </div>
    <button class="btn btn-outline" id="use-gps" style="margin-bottom:14px;">📡 Use my current location for pickup</button>

    <div class="field">
      <label>VEHICLE</label>
      <div class="vehtabs" id="veh-tabs">
        <button data-v="rickshaw" class="active">🛺 Rickshaw</button>
        <button data-v="car">🚗 Car</button>
        <button data-v="hiace">🚐 Hiace</button>
      </div>
    </div>

    <div id="fare-section" style="display:none;">
      <div class="fare-slider-value display" id="fare-value">Rs 0</div>
      <input type="range" id="fare-slider" style="width:100%;" />
      <div class="fare-range-note" id="fare-note"></div>
    </div>

    <button class="btn btn-gold" id="request-ride-btn" disabled>Set pickup & destination first</button>
  `);

  document.getElementById("r-logout").onclick = () => {
    localStorage.removeItem("riderToken"); localStorage.removeItem("riderInfo");
    state.riderToken = null; state.riderInfo = null;
    renderRiderAuth();
  };

  setTimeout(initRiderMap, 0);

  document.getElementById("mode-pickup").onclick = () => setPickMode("pickup");
  document.getElementById("mode-dest").onclick = () => setPickMode("dest");
  document.getElementById("use-gps").onclick = useGpsForPickup;
  document.querySelectorAll("#veh-tabs button").forEach(b => b.onclick = () => {
    document.querySelectorAll("#veh-tabs button").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    rideState.vehicle = b.dataset.v;
    refreshFareEstimate();
  });
  document.getElementById("request-ride-btn").onclick = submitRideRequest;

  ensureSocket(state.riderToken);
  socket.off("ride:accepted"); socket.off("ride:location"); socket.off("ride:completed");
  socket.on("ride:accepted", (ride) => { rideState.activeRide = ride; renderActiveRide(ride); });
  socket.on("ride:location", ({ rideId, lat, lng }) => { updateDriverMarker(lat, lng); });
  socket.on("ride:completed", (ride) => { renderRideCompleted(ride); });
}

function initRiderMap() {
  riderMap = L.map("map").setView(HARIPUR_CENTER, 13);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap contributors" }).addTo(riderMap);
  riderMap.on("click", (e) => {
    if (pickMode === "pickup") setPickup(e.latlng.lat, e.latlng.lng, "Pinned pickup point");
    else setDest(e.latlng.lat, e.latlng.lng, "Pinned destination");
  });
}
function setPickMode(mode) {
  pickMode = mode;
  document.getElementById("mode-pickup").classList.toggle("active", mode === "pickup");
  document.getElementById("mode-dest").classList.toggle("active", mode === "dest");
}
function useGpsForPickup() {
  if (!navigator.geolocation) return showMsg("Your browser doesn't support location access.");
  navigator.geolocation.getCurrentPosition(
    (pos) => setPickup(pos.coords.latitude, pos.coords.longitude, "Current location"),
    () => showMsg("Couldn't get your location — tap the map to set pickup instead.")
  );
}
function setPickup(lat, lng, label) {
  rideState.pickup = { lat, lng, label };
  if (pickupMarker) riderMap.removeLayer(pickupMarker);
  pickupMarker = L.marker([lat, lng]).addTo(riderMap).bindPopup("Pickup: " + label).openPopup();
  riderMap.setView([lat, lng], 14);
  refreshFareEstimate();
}
function setDest(lat, lng, label) {
  rideState.dest = { lat, lng, label };
  if (destMarker) riderMap.removeLayer(destMarker);
  destMarker = L.marker([lat, lng]).addTo(riderMap).bindPopup("Destination: " + label).openPopup();
  refreshFareEstimate();
}

async function refreshFareEstimate() {
  const btn = document.getElementById("request-ride-btn");
  if (!rideState.pickup || !rideState.dest) {
    btn.disabled = true; btn.textContent = "Set pickup & destination first";
    document.getElementById("fare-section").style.display = "none";
    return;
  }
  try {
    const est = await api(`/api/rides/fare-estimate?vehicleType=${rideState.vehicle}&pickupLat=${rideState.pickup.lat}&pickupLng=${rideState.pickup.lng}&destLat=${rideState.dest.lat}&destLng=${rideState.dest.lng}`);
    document.getElementById("fare-section").style.display = "block";
    const slider = document.getElementById("fare-slider");
    slider.min = est.min; slider.max = est.max; slider.step = 5;
    slider.value = Math.round((est.min + est.max) / 2 / 5) * 5;
    document.getElementById("fare-value").textContent = `Rs ${slider.value}`;
    document.getElementById("fare-note").textContent = `${est.km} km · Rs ${est.min}–Rs ${est.max} range for this trip`;
    slider.oninput = () => document.getElementById("fare-value").textContent = `Rs ${slider.value}`;
    rideState.fare = { min: est.min, max: est.max };
    btn.disabled = false; btn.textContent = "Request ride";
  } catch (e) { showMsg(e.message); }
}

async function submitRideRequest() {
  const fare = +document.getElementById("fare-slider").value;
  try {
    const ride = await api("/api/rides", {
      method: "POST", token: state.riderToken,
      body: {
        pickupLat: rideState.pickup.lat, pickupLng: rideState.pickup.lng, pickupAddress: rideState.pickup.label,
        destLat: rideState.dest.lat, destLng: rideState.dest.lng, destAddress: rideState.dest.label,
        vehicleType: rideState.vehicle, offeredFare: fare,
      }
    });
    rideState.activeRide = ride;
    renderSearching(ride);
  } catch (e) { showMsg(e.message); }
}

function renderSearching(ride) {
  render(`
    <div class="card" style="text-align:center;">
      <div class="pulse">${ride.vehicleType === "rickshaw" ? "🛺" : ride.vehicleType === "car" ? "🚗" : "🚐"}</div>
      <h3 class="display" style="margin:16px 0 4px;">Looking for a driver…</h3>
      <p class="muted">Offering Rs ${ride.offeredFare} · ${ride.pickupAddress} → ${ride.destAddress}</p>
    </div>
    <button class="btn btn-outline" id="cancel-search">Cancel</button>
  `);
  document.getElementById("cancel-search").onclick = () => renderRiderHome();
}

function renderActiveRide(ride) {
  render(`
    <div class="card">
      <div class="driver-status-pill pill-approved">DRIVER ON THE WAY</div>
      <h3 class="display" style="margin:10px 0 2px;">${ride.driverName}</h3>
      <p class="muted">${ride.driverVehicleType} · Fare Rs ${ride.offeredFare}</p>
    </div>
    <div id="map"></div>
    <button class="btn btn-outline" id="back-btn" style="margin-top:12px;">Back</button>
  `);
  setTimeout(() => {
    riderMap = L.map("map").setView([ride.pickupLat, ride.pickupLng], 14);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap contributors" }).addTo(riderMap);
    L.marker([ride.pickupLat, ride.pickupLng]).addTo(riderMap).bindPopup("Pickup");
    L.marker([ride.destLat, ride.destLng]).addTo(riderMap).bindPopup("Destination");
  }, 0);
  document.getElementById("back-btn").onclick = () => renderRiderHome();
}
function updateDriverMarker(lat, lng) {
  if (!riderMap) return;
  if (window.__driverMarker) riderMap.removeLayer(window.__driverMarker);
  window.__driverMarker = L.marker([lat, lng], { title: "Driver" }).addTo(riderMap).bindPopup("Your driver");
}
function renderRideCompleted(ride) {
  render(`
    <div class="card" style="text-align:center;">
      <h3 class="display">Trip complete</h3>
      <p class="muted">Fare paid: Rs ${ride.offeredFare}</p>
    </div>
    <button class="btn btn-gold" id="new-ride-btn">Book another ride</button>
  `);
  document.getElementById("new-ride-btn").onclick = () => renderRiderHome();
}

/* =============================== DRIVER =============================== */

function renderDriverAuth() {
  render(`
    <div id="msg"></div>
    <div class="card">
      <h3 class="display" style="margin:0 0 10px;font-size:20px;">Driver login</h3>
      <div class="field"><label>PHONE</label><input id="d-phone" placeholder="03xxxxxxxxx"/></div>
      <div class="field"><label>PASSWORD</label><input id="d-pass" type="password"/></div>
      <button class="btn btn-gold" id="d-login-btn">Log in</button>
      <div style="height:8px;"></div>
      <button class="btn btn-dark" id="d-fingerprint-btn">🔒 Log in with fingerprint</button>
    </div>
    <div class="card">
      <h3 class="display" style="margin:0 0 10px;font-size:20px;">Register as a driver</h3>
      <p class="muted" style="margin-top:0;">Your account needs admin approval before you can accept rides.</p>
      <div class="field"><label>FULL NAME</label><input id="d-name"/></div>
      <div class="field"><label>PHONE</label><input id="d-phone2" placeholder="03xxxxxxxxx"/></div>
      <div class="field"><label>PASSWORD</label><input id="d-pass2" type="password"/></div>
      <div class="field"><label>CNIC NUMBER</label><input id="d-cnic" placeholder="xxxxx-xxxxxxx-x"/></div>
      <div class="field">
        <label>VEHICLE TYPE</label>
        <select id="d-vehicle">
          <option value="rickshaw">Bike Rickshaw</option>
          <option value="car">Car</option>
          <option value="hiace">Hiace</option>
        </select>
      </div>
      <div class="field"><label>VEHICLE CC (e.g. 100, 1300, 2700)</label><input id="d-cc" type="number"/></div>
      <div class="field"><label>CNIC PHOTO</label><input id="d-cnic-photo" type="file" accept="image/*"/></div>
      <div class="field"><label>YOUR PHOTO</label><input id="d-profile-photo" type="file" accept="image/*"/></div>
      <div class="field"><label>DRIVING LICENSE PHOTO</label><input id="d-license-photo" type="file" accept="image/*"/></div>
      <div class="field"><label>VEHICLE DOCUMENT PHOTO</label><input id="d-vehicle-doc" type="file" accept="image/*"/></div>
      <button class="btn btn-dark" id="d-register-btn">Submit registration</button>
    </div>
  `);

  document.getElementById("d-login-btn").onclick = async () => {
    try {
      const data = await api("/api/auth/driver/login", { method: "POST", body: { phone: val("d-phone"), password: val("d-pass") } });
      saveDriverSession(data);
    } catch (e) { showMsg(e.message); }
  };

  document.getElementById("d-fingerprint-btn").onclick = async () => {
    try {
      const phone = prompt("Enter your registered phone number:");
      if (!phone) return;
      const { options, driverId } = await api("/api/driver/webauthn/login-options", { method: "POST", body: { phone } });
      const assertion = await SimpleWebAuthnBrowser.startAuthentication(options);
      const data = await api("/api/driver/webauthn/login-verify", { method: "POST", body: { driverId, assertion } });
      saveDriverSession(data);
    } catch (e) { showMsg(e.message); }
  };

  document.getElementById("d-register-btn").onclick = async () => {
    try {
      const fd = new FormData();
      fd.append("name", val("d-name"));
      fd.append("phone", val("d-phone2"));
      fd.append("password", val("d-pass2"));
      fd.append("cnicNumber", val("d-cnic"));
      fd.append("vehicleType", document.getElementById("d-vehicle").value);
      fd.append("vehicleCc", val("d-cc"));
      fd.append("cnicPhoto", document.getElementById("d-cnic-photo").files[0]);
      fd.append("profilePhoto", document.getElementById("d-profile-photo").files[0]);
      fd.append("licensePhoto", document.getElementById("d-license-photo").files[0]);
      fd.append("vehicleDoc", document.getElementById("d-vehicle-doc").files[0]);
      const data = await api("/api/auth/driver/register", { method: "POST", body: fd, isForm: true });
      showMsg(data.message, "success");
    } catch (e) { showMsg(e.message); }
  };
}

function saveDriverSession(data) {
  state.driverToken = data.token; state.driverInfo = data.driver;
  localStorage.setItem("driverToken", data.token);
  localStorage.setItem("driverInfo", JSON.stringify(data.driver));
  ensureSocket(data.token);
  renderDriverHome();
}

let driverOnline = false, currentOffer = null, watchId = null;

function renderDriverHome() {
  render(`
    <div class="muted" style="margin-bottom:10px;">Hi ${state.driverInfo.name} (${state.driverInfo.vehicleType}) · <button class="link-btn" id="d-logout">Log out</button></div>
    <div id="msg"></div>
    <div class="btn-row" style="margin-bottom:16px;">
      <button class="btn ${driverOnline ? 'btn-green' : 'btn-outline'}" id="toggle-online">${driverOnline ? "🟢 Online" : "⚪ Go online"}</button>
      <button class="btn btn-outline" id="enroll-fingerprint">🔒 Set up fingerprint login</button>
    </div>
    <div id="driver-main"></div>
  `);
  document.getElementById("d-logout").onclick = () => {
    localStorage.removeItem("driverToken"); localStorage.removeItem("driverInfo");
    state.driverToken = null; state.driverInfo = null;
    driverOnline = false;
    if (watchId) navigator.geolocation.clearWatch(watchId);
    renderDriverAuth();
  };
  document.getElementById("toggle-online").onclick = toggleOnline;
  document.getElementById("enroll-fingerprint").onclick = enrollFingerprint;

  ensureSocket(state.driverToken);
  socket.off("ride:new"); socket.off("ride:taken");
  socket.on("ride:new", (ride) => { currentOffer = ride; renderDriverOffer(ride); });
  socket.on("ride:taken", ({ id }) => { if (currentOffer && currentOffer.id === id) { currentOffer = null; renderDriverIdle(); } });

  renderDriverIdle();
}

async function toggleOnline() {
  try {
    const res = await api("/api/driver/online", { method: "POST", token: state.driverToken, body: { online: !driverOnline } });
    driverOnline = res.online;
    renderDriverHome();
  } catch (e) { showMsg(e.message); }
}

function renderDriverIdle() {
  const main = document.getElementById("driver-main");
  if (!main) return;
  main.innerHTML = driverOnline
    ? `<div class="card" style="text-align:center;"><div class="pulse">⏳</div><p class="muted" style="margin-top:12px;">Waiting for ride offers…</p></div>`
    : `<div class="card" style="text-align:center;"><p class="muted">You're offline. Go online to receive ride offers.</p></div>`;
}

function renderDriverOffer(ride) {
  const main = document.getElementById("driver-main");
  if (!main) return;
  main.innerHTML = `
    <div class="card">
      <div class="driver-status-pill pill-pending">NEW RIDE OFFER</div>
      <p style="margin:8px 0 4px;font-weight:600;">${ride.pickupAddress} → ${ride.destAddress}</p>
      <p class="muted">${ride.km} km · Rider: ${ride.riderName}</p>
      <div class="offer-row"><span>Offered fare</span><span class="offer-fare display">Rs ${ride.offeredFare}</span></div>
      <div class="btn-row">
        <button class="btn btn-outline" id="skip-btn">Skip</button>
        <button class="btn btn-gold" id="accept-btn">Accept</button>
      </div>
    </div>
  `;
  document.getElementById("skip-btn").onclick = () => respondToRide(ride.id, "skip");
  document.getElementById("accept-btn").onclick = () => respondToRide(ride.id, "accept");
}

async function respondToRide(rideId, action) {
  try {
    const ride = await api(`/api/rides/${rideId}/respond`, { method: "POST", token: state.driverToken, body: { action } });
    currentOffer = null;
    if (action === "accept") { startSharingLocation(ride.id); renderDriverActiveRide(ride); }
    else renderDriverIdle();
  } catch (e) { showMsg(e.message); renderDriverIdle(); }
}

function startSharingLocation(rideId) {
  if (!navigator.geolocation) return;
  if (watchId) navigator.geolocation.clearWatch(watchId);
  watchId = navigator.geolocation.watchPosition((pos) => {
    api(`/api/rides/${rideId}/location`, { method: "POST", token: state.driverToken, body: { lat: pos.coords.latitude, lng: pos.coords.longitude } }).catch(() => {});
  }, () => {}, { enableHighAccuracy: true, maximumAge: 5000 });
}

function renderDriverActiveRide(ride) {
  const main = document.getElementById("driver-main");
  main.innerHTML = `
    <div class="card">
      <div class="driver-status-pill pill-approved">RIDE IN PROGRESS</div>
      <p style="margin:8px 0 4px;font-weight:600;">${ride.pickupAddress} → ${ride.destAddress}</p>
      <p class="muted">Fare Rs ${ride.offeredFare}</p>
      <button class="btn btn-gold" id="complete-btn" style="margin-top:10px;">Mark trip complete</button>
    </div>
  `;
  document.getElementById("complete-btn").onclick = async () => {
    try {
      await api(`/api/rides/${ride.id}/complete`, { method: "POST", token: state.driverToken });
      if (watchId) navigator.geolocation.clearWatch(watchId);
      renderDriverIdle();
    } catch (e) { showMsg(e.message); }
  };
}

async function enrollFingerprint() {
  try {
    const options = await api("/api/driver/webauthn/register-options", { method: "POST", token: state.driverToken });
    const attestation = await SimpleWebAuthnBrowser.startRegistration(options);
    await api("/api/driver/webauthn/register-verify", { method: "POST", token: state.driverToken, body: attestation });
    showMsg("Fingerprint login set up. You can use it next time you log in.", "success");
  } catch (e) { showMsg(e.message); }
}

/* =============================== ADMIN =============================== */

function renderAdminAuth() {
  render(`
    <div id="msg"></div>
    <div class="card">
      <h3 class="display" style="margin:0 0 10px;">Admin login</h3>
      <div class="field"><label>ADMIN PHONE / USERNAME</label><input id="a-phone"/></div>
      <div class="field"><label>PASSWORD</label><input id="a-pass" type="password"/></div>
      <button class="btn btn-gold" id="a-login-btn">Log in</button>
    </div>
  `);
  document.getElementById("a-login-btn").onclick = async () => {
    try {
      const data = await api("/api/auth/admin/login", { method: "POST", body: { phone: val("a-phone"), password: val("a-pass") } });
      state.adminToken = data.token; localStorage.setItem("adminToken", data.token);
      renderAdminHome();
    } catch (e) { showMsg(e.message); }
  };
}

async function renderAdminHome() {
  render(`<div id="msg"></div><div id="admin-content">Loading…</div>`);
  await loadAdminDrivers();
}

async function loadAdminDrivers() {
  try {
    const drivers = await api("/api/admin/drivers", { token: state.adminToken });
    const fareConfig = await api("/api/admin/fare-config", { token: state.adminToken });
    document.getElementById("admin-content").innerHTML = `
      <div style="text-align:right;margin-bottom:8px;"><button class="link-btn" id="a-logout">Log out</button></div>
      <h3 class="display" style="margin:0 0 8px;">Driver registrations</h3>
      ${drivers.map(d => `
        <div class="card">
          <div class="driver-status-pill pill-${d.status}">${d.status}</div>
          <p style="font-weight:600;margin:8px 0 2px;">${d.name} · ${d.phone}</p>
          <p class="muted" style="margin:0 0 6px;">${d.vehicleType} ${d.vehicleCc ? `(${d.vehicleCc}cc)` : ""} · CNIC ${d.cnicNumber}</p>
          <div class="doc-links" style="margin-bottom:8px;">
            <a href="/api/admin/drivers/${d.id}/documents/cnicPhoto?token=${state.adminToken}" target="_blank">CNIC photo</a>
            <a href="/api/admin/drivers/${d.id}/documents/profilePhoto?token=${state.adminToken}" target="_blank">Profile photo</a>
            <a href="/api/admin/drivers/${d.id}/documents/licensePhoto?token=${state.adminToken}" target="_blank">License</a>
            <a href="/api/admin/drivers/${d.id}/documents/vehicleDoc?token=${state.adminToken}" target="_blank">Vehicle doc</a>
          </div>
          <div class="btn-row">
            <button class="btn btn-green" data-approve="${d.id}">Approve</button>
            <button class="btn btn-danger" data-block="${d.id}">Block</button>
          </div>
        </div>
      `).join("")}

      <h3 class="display" style="margin:20px 0 8px;">Fare configuration</h3>
      ${["rickshaw", "car", "hiace"].map(v => `
        <div class="card">
          <p style="font-weight:600;margin:0 0 8px;text-transform:capitalize;">${v}</p>
          <div class="field"><label>BASE FARE (Rs)</label><input data-fare="${v}-base" type="number" value="${fareConfig[v].baseFare}"/></div>
          <div class="field"><label>MIN RS/KM</label><input data-fare="${v}-min" type="number" value="${fareConfig[v].minPerKm}"/></div>
          <div class="field"><label>MAX RS/KM</label><input data-fare="${v}-max" type="number" value="${fareConfig[v].maxPerKm}"/></div>
          <button class="btn btn-dark" data-save-fare="${v}">Save ${v} fare rules</button>
        </div>
      `).join("")}
    `;
    document.getElementById("a-logout").onclick = () => { localStorage.removeItem("adminToken"); state.adminToken = null; renderAdminAuth(); };
    document.querySelectorAll("[data-approve]").forEach(b => b.onclick = () => setDriverStatus(b.dataset.approve, "approved"));
    document.querySelectorAll("[data-block]").forEach(b => b.onclick = () => setDriverStatus(b.dataset.block, "blocked"));
    document.querySelectorAll("[data-save-fare]").forEach(b => b.onclick = () => saveFareConfig(b.dataset.saveFare));
  } catch (e) { showMsg(e.message); }
}

async function setDriverStatus(id, status) {
  try { await api(`/api/admin/drivers/${id}/status`, { method: "POST", token: state.adminToken, body: { status } }); loadAdminDrivers(); }
  catch (e) { showMsg(e.message); }
}
async function saveFareConfig(vehicleType) {
  try {
    await api("/api/admin/fare-config", {
      method: "POST", token: state.adminToken,
      body: {
        vehicleType,
        baseFare: val(`[data-fare="${vehicleType}-base"]`, true),
        minPerKm: val(`[data-fare="${vehicleType}-min"]`, true),
        maxPerKm: val(`[data-fare="${vehicleType}-max"]`, true),
      }
    });
    showMsg(`${vehicleType} fare rules saved`, "success");
  } catch (e) { showMsg(e.message); }
}

/* ---------------- small helpers ---------------- */
function val(idOrSelector, isSelector = false) {
  const el = isSelector ? document.querySelector(idOrSelector) : document.getElementById(idOrSelector);
  return el ? el.value : "";
}
function showMsg(text, kind = "error") {
  const box = document.getElementById("msg");
  if (!box) return;
  box.innerHTML = `<div class="${kind === "error" ? "error-box" : "success-box"}">${text}</div>`;
}

/* ---------------- boot ---------------- */
routeTo(state.role);
