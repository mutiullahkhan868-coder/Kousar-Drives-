const express = require("express");
const { v4: uuidv4 } = require("uuid");
const {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} = require("@simplewebauthn/server");
const { transact, readDb } = require("../data/store");
const { requireAuth, sign } = require("../middleware/auth");

const router = express.Router();

// IMPORTANT: rpID must match the domain you deploy this on (e.g. "kousardrives.com").
// "localhost" only works for local testing.
const RP_NAME = "Kousar Drives";
const RP_ID = process.env.WEBAUTHN_RP_ID || "localhost";
const ORIGIN = process.env.WEBAUTHN_ORIGIN || `http://${RP_ID}:3000`;

router.get("/me", requireAuth("driver"), (req, res) => {
  const db = readDb();
  const driver = db.drivers.find(d => d.id === req.user.id);
  if (!driver) return res.status(404).json({ error: "Driver not found" });
  const { passwordHash, ...safe } = driver;
  res.json(safe);
});

router.post("/online", requireAuth("driver"), async (req, res) => {
  const { online } = req.body;
  const driver = await transact((db) => {
    const d = db.drivers.find(d => d.id === req.user.id);
    if (!d) throw new Error("Driver not found");
    if (d.status !== "approved") throw new Error("Your account is not approved to take rides yet");
    d.online = !!online;
    return d;
  }).catch(e => { throw e; });
  res.json({ online: driver.online });
});

/* ---------------- WebAuthn (fingerprint / device biometric) login ---------------- */
// Flow: driver logs in once normally with phone+password, then can "enroll" their
// fingerprint (really: the phone's platform authenticator) so future logins are one-tap.

router.post("/webauthn/register-options", requireAuth("driver"), async (req, res) => {
  const options = await generateRegistrationOptions({
    rpName: RP_NAME,
    rpID: RP_ID,
    userID: Buffer.from(req.user.id),
    userName: req.user.name,
    authenticatorSelection: { authenticatorAttachment: "platform", userVerification: "required" },
  });
  await transact((db) => { db.webauthnChallenges[req.user.id] = options.challenge; });
  res.json(options);
});

router.post("/webauthn/register-verify", requireAuth("driver"), async (req, res) => {
  const db = readDb();
  const expectedChallenge = db.webauthnChallenges[req.user.id];
  try {
    const verification = await verifyRegistrationResponse({
      response: req.body,
      expectedChallenge,
      expectedOrigin: ORIGIN,
      expectedRPID: RP_ID,
    });
    if (!verification.verified) return res.status(400).json({ error: "Could not verify fingerprint registration" });

    const { credential } = verification.registrationInfo;
    await transact((db) => {
      db.webauthnCredentials.push({
        driverId: req.user.id,
        credentialId: credential.id,
        publicKey: Buffer.from(credential.publicKey).toString("base64"),
        counter: credential.counter,
      });
    });
    res.json({ verified: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Step 1 of fingerprint login: driver enters their phone number, server returns a challenge
router.post("/webauthn/login-options", async (req, res) => {
  const { phone } = req.body;
  const db = readDb();
  const driver = db.drivers.find(d => d.phone === phone);
  if (!driver) return res.status(404).json({ error: "No driver with this phone number" });
  const creds = db.webauthnCredentials.filter(c => c.driverId === driver.id);
  if (!creds.length) return res.status(400).json({ error: "Fingerprint login not set up for this account yet" });

  const options = await generateAuthenticationOptions({
    rpID: RP_ID,
    userVerification: "required",
    allowCredentials: creds.map(c => ({ id: c.credentialId })),
  });
  await transact((db) => { db.webauthnChallenges[driver.id] = options.challenge; });
  res.json({ options, driverId: driver.id });
});

// Step 2 of fingerprint login: browser sends back the biometric assertion
router.post("/webauthn/login-verify", async (req, res) => {
  const { driverId, assertion } = req.body;
  const db = readDb();
  const driver = db.drivers.find(d => d.id === driverId);
  const cred = db.webauthnCredentials.find(c => c.driverId === driverId && c.credentialId === assertion.id);
  if (!driver || !cred) return res.status(400).json({ error: "Fingerprint credential not recognized" });

  try {
    const verification = await verifyAuthenticationResponse({
      response: assertion,
      expectedChallenge: db.webauthnChallenges[driverId],
      expectedOrigin: ORIGIN,
      expectedRPID: RP_ID,
      credential: { id: cred.credentialId, publicKey: Buffer.from(cred.publicKey, "base64"), counter: cred.counter },
    });
    if (!verification.verified) return res.status(400).json({ error: "Fingerprint did not match" });

    await transact((db) => {
      const c = db.webauthnCredentials.find(c => c.driverId === driverId && c.credentialId === assertion.id);
      c.counter = verification.authenticationInfo.newCounter;
    });

    if (driver.status !== "approved") return res.status(403).json({ error: "Account not approved or is blocked" });
    const token = sign({ id: driver.id, role: "driver", name: driver.name });
    res.json({ token, driver: { id: driver.id, name: driver.name, phone: driver.phone, vehicleType: driver.vehicleType } });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

module.exports = router;
