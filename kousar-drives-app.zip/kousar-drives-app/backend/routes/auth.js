const express = require("express");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const path = require("path");
const { v4: uuidv4 } = require("uuid");
const { transact } = require("../data/store");
const { sign } = require("../middleware/auth");

const router = express.Router();

const storage = multer.diskStorage({
  destination: path.join(__dirname, "..", "uploads"),
  filename: (req, file, cb) => {
    cb(null, `${uuidv4()}-${file.fieldname}${path.extname(file.originalname)}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 8 * 1024 * 1024 } }); // 8MB per file

/* ---------------- RIDER signup / login ---------------- */

router.post("/rider/signup", async (req, res) => {
  const { name, phone, password } = req.body;
  if (!name || !phone || !password) return res.status(400).json({ error: "name, phone, password are required" });

  const passwordHash = await bcrypt.hash(password, 10);
  try {
    const rider = await transact((db) => {
      if (db.riders.find(r => r.phone === phone)) throw new Error("A rider with this phone number already exists");
      const newRider = { id: uuidv4(), name, phone, passwordHash, createdAt: Date.now() };
      db.riders.push(newRider);
      return newRider;
    });
    const token = sign({ id: rider.id, role: "rider", name: rider.name });
    res.json({ token, rider: { id: rider.id, name: rider.name, phone: rider.phone } });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.post("/rider/login", async (req, res) => {
  const { phone, password } = req.body;
  const db = require("../data/store").readDb();
  const rider = db.riders.find(r => r.phone === phone);
  if (!rider) return res.status(401).json({ error: "No account with this phone number" });
  const ok = await bcrypt.compare(password, rider.passwordHash);
  if (!ok) return res.status(401).json({ error: "Incorrect password" });
  const token = sign({ id: rider.id, role: "rider", name: rider.name });
  res.json({ token, rider: { id: rider.id, name: rider.name, phone: rider.phone } });
});

/* ---------------- DRIVER registration (with documents) ---------------- */
// Fields: name, phone, password, cnicNumber, vehicleType (rickshaw|car|hiace), vehicleCc
// Files: cnicPhoto, profilePhoto, licensePhoto, vehicleDoc

router.post(
  "/driver/register",
  upload.fields([
    { name: "cnicPhoto", maxCount: 1 },
    { name: "profilePhoto", maxCount: 1 },
    { name: "licensePhoto", maxCount: 1 },
    { name: "vehicleDoc", maxCount: 1 },
  ]),
  async (req, res) => {
    const { name, phone, password, cnicNumber, vehicleType, vehicleCc } = req.body;
    if (!name || !phone || !password || !cnicNumber || !vehicleType) {
      return res.status(400).json({ error: "name, phone, password, cnicNumber, vehicleType are required" });
    }
    if (!["rickshaw", "car", "hiace"].includes(vehicleType)) {
      return res.status(400).json({ error: "vehicleType must be rickshaw, car, or hiace" });
    }
    const files = req.files || {};
    if (!files.cnicPhoto || !files.profilePhoto || !files.licensePhoto || !files.vehicleDoc) {
      return res.status(400).json({ error: "CNIC photo, profile photo, license photo, and vehicle document are all required" });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    try {
      const driver = await transact((db) => {
        if (db.drivers.find(d => d.phone === phone)) throw new Error("A driver with this phone number already exists");
        const newDriver = {
          id: uuidv4(),
          name, phone, passwordHash, cnicNumber,
          vehicleType, vehicleCc: vehicleCc || null,
          documents: {
            cnicPhoto: files.cnicPhoto[0].filename,
            profilePhoto: files.profilePhoto[0].filename,
            licensePhoto: files.licensePhoto[0].filename,
            vehicleDoc: files.vehicleDoc[0].filename,
          },
          status: "pending", // pending | approved | blocked | rejected
          online: false,
          createdAt: Date.now(),
        };
        db.drivers.push(newDriver);
        return newDriver;
      });
      res.json({
        message: "Registration submitted. An admin must approve your account before you can accept rides.",
        driverId: driver.id,
        status: driver.status,
      });
    } catch (e) {
      res.status(400).json({ error: e.message });
    }
  }
);

router.post("/driver/login", async (req, res) => {
  const { phone, password } = req.body;
  const db = require("../data/store").readDb();
  const driver = db.drivers.find(d => d.phone === phone);
  if (!driver) return res.status(401).json({ error: "No driver account with this phone number" });
  const ok = await bcrypt.compare(password, driver.passwordHash);
  if (!ok) return res.status(401).json({ error: "Incorrect password" });
  if (driver.status === "pending") return res.status(403).json({ error: "Your registration is still pending admin approval" });
  if (driver.status === "blocked") return res.status(403).json({ error: "Your account has been blocked by the admin" });
  if (driver.status === "rejected") return res.status(403).json({ error: "Your registration was rejected" });

  const token = sign({ id: driver.id, role: "driver", name: driver.name });
  res.json({ token, driver: { id: driver.id, name: driver.name, phone: driver.phone, vehicleType: driver.vehicleType, status: driver.status } });
});

/* ---------------- ADMIN login ----------------
   Single admin account, set via environment variables.
   Change ADMIN_PHONE / ADMIN_PASSWORD before deploying. */

router.post("/admin/login", async (req, res) => {
  const { phone, password } = req.body;
  const ADMIN_PHONE = process.env.ADMIN_PHONE || "admin";
  const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "changeme123";
  if (phone !== ADMIN_PHONE || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Incorrect admin credentials" });
  }
  const token = sign({ id: "admin", role: "admin", name: "Admin" });
  res.json({ token });
});

module.exports = router;
