const express = require("express");
const { transact, readDb } = require("../data/store");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth("admin"));

router.get("/drivers", (req, res) => {
  const db = readDb();
  const drivers = db.drivers.map(({ passwordHash, ...safe }) => safe);
  res.json(drivers);
});

router.get("/drivers/:id/documents/:field", (req, res) => {
  // Serves an uploaded document image so the admin can review it.
  const db = readDb();
  const driver = db.drivers.find(d => d.id === req.params.id);
  if (!driver || !driver.documents[req.params.field]) return res.status(404).end();
  res.sendFile(require("path").join(__dirname, "..", "uploads", driver.documents[req.params.field]));
});

router.post("/drivers/:id/status", async (req, res) => {
  const { status } = req.body; // approved | blocked | rejected | pending
  if (!["approved", "blocked", "rejected", "pending"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }
  try {
    const driver = await transact((db) => {
      const d = db.drivers.find(d => d.id === req.params.id);
      if (!d) throw new Error("Driver not found");
      d.status = status;
      if (status !== "approved") d.online = false; // blocked/rejected drivers can't stay online
      return d;
    });
    const { passwordHash, ...safe } = driver;
    res.json(safe);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.get("/rides", (req, res) => {
  const db = readDb();
  res.json(db.rides.slice().reverse().slice(0, 200));
});

router.get("/fare-config", (req, res) => {
  res.json(readDb().fareConfig);
});

router.post("/fare-config", async (req, res) => {
  const { vehicleType, baseFare, minPerKm, maxPerKm, ccNote } = req.body;
  if (!["rickshaw", "car", "hiace"].includes(vehicleType)) return res.status(400).json({ error: "Invalid vehicleType" });
  if (minPerKm > maxPerKm) return res.status(400).json({ error: "minPerKm cannot be greater than maxPerKm" });

  const config = await transact((db) => {
    db.fareConfig[vehicleType] = {
      baseFare: +baseFare,
      minPerKm: +minPerKm,
      maxPerKm: +maxPerKm,
      ccNote: ccNote || db.fareConfig[vehicleType].ccNote,
    };
    return db.fareConfig;
  });
  res.json(config);
});

router.get("/riders", (req, res) => {
  const db = readDb();
  res.json(db.riders.map(({ passwordHash, ...safe }) => safe));
});

module.exports = router;
