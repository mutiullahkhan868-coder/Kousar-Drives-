const express = require("express");
const { v4: uuidv4 } = require("uuid");
const { transact, readDb } = require("../data/store");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function fareRangeFor(vehicleType, km, fareConfig) {
  const cfg = fareConfig[vehicleType];
  if (!cfg) throw new Error("Unknown vehicle type");
  const min = Math.round((cfg.baseFare + km * cfg.minPerKm) / 5) * 5;
  const max = Math.round((cfg.baseFare + km * cfg.maxPerKm) / 5) * 5;
  return { min, max };
}

// Public: used by the rider app to show the min/max slider before submitting
router.get("/fare-estimate", (req, res) => {
  const { vehicleType, pickupLat, pickupLng, destLat, destLng } = req.query;
  if (!vehicleType || !pickupLat || !pickupLng || !destLat || !destLng) {
    return res.status(400).json({ error: "vehicleType, pickupLat, pickupLng, destLat, destLng are required" });
  }
  const db = readDb();
  const km = haversineKm(+pickupLat, +pickupLng, +destLat, +destLng);
  try {
    const range = fareRangeFor(vehicleType, km, db.fareConfig);
    res.json({ km: +km.toFixed(1), ...range });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Rider creates a new ride request
router.post("/", requireAuth("rider"), async (req, res) => {
  const { pickupLat, pickupLng, pickupAddress, destLat, destLng, destAddress, vehicleType, offeredFare } = req.body;
  if ([pickupLat, pickupLng, destLat, destLng, vehicleType, offeredFare].some(v => v === undefined || v === null)) {
    return res.status(400).json({ error: "pickupLat, pickupLng, destLat, destLng, vehicleType, offeredFare are required" });
  }

  const db = readDb();
  const km = haversineKm(+pickupLat, +pickupLng, +destLat, +destLng);
  let range;
  try {
    range = fareRangeFor(vehicleType, km, db.fareConfig);
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }
  if (offeredFare < range.min || offeredFare > range.max) {
    return res.status(400).json({ error: `Offer must be between Rs ${range.min} and Rs ${range.max} for this trip` });
  }

  const ride = await transact((db) => {
    const newRide = {
      id: uuidv4(),
      riderId: req.user.id,
      riderName: req.user.name,
      pickupLat: +pickupLat, pickupLng: +pickupLng, pickupAddress: pickupAddress || "Pickup point",
      destLat: +destLat, destLng: +destLng, destAddress: destAddress || "Destination",
      vehicleType, offeredFare, km: +km.toFixed(1),
      status: "searching", // searching | accepted | completed | cancelled
      driverId: null,
      skippedBy: [],
      driverLocation: null,
      createdAt: Date.now(),
    };
    db.rides.push(newRide);
    return newRide;
  });

  // Notify all online, approved drivers of the matching vehicle type
  const io = req.app.get("io");
  const eligibleDrivers = db.drivers.filter(d => d.status === "approved" && d.online && d.vehicleType === vehicleType);
  eligibleDrivers.forEach(d => io.to(`driver:${d.id}`).emit("ride:new", ride));

  res.json(ride);
});

router.get("/:id", requireAuth(), (req, res) => {
  const db = readDb();
  const ride = db.rides.find(r => r.id === req.params.id);
  if (!ride) return res.status(404).json({ error: "Ride not found" });
  res.json(ride);
});

// Driver accepts or skips a ride offer
router.post("/:id/respond", requireAuth("driver"), async (req, res) => {
  const { action } = req.body; // "accept" | "skip"
  if (!["accept", "skip"].includes(action)) return res.status(400).json({ error: "action must be accept or skip" });

  let updated;
  try {
    updated = await transact((db) => {
      const ride = db.rides.find(r => r.id === req.params.id);
      if (!ride) throw new Error("Ride not found");
      if (ride.status !== "searching") throw new Error("This ride is no longer available");

      if (action === "skip") {
        ride.skippedBy.push(req.user.id);
        return { ride, action: "skip" };
      }
      ride.status = "accepted";
      ride.driverId = req.user.id;
      const driver = db.drivers.find(d => d.id === req.user.id);
      ride.driverName = driver ? driver.name : "Driver";
      ride.driverVehicleType = driver ? driver.vehicleType : ride.vehicleType;
      return { ride, action: "accept" };
    });
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }

  const io = req.app.get("io");
  if (updated.action === "accept") {
    io.to(`rider:${updated.ride.riderId}`).emit("ride:accepted", updated.ride);
    // Let other drivers know it's taken so their UI can clear it
    io.emit("ride:taken", { id: updated.ride.id });
  }
  res.json(updated.ride);
});

// Driver pushes a live location update while on an active ride
router.post("/:id/location", requireAuth("driver"), async (req, res) => {
  const { lat, lng } = req.body;
  if (lat === undefined || lng === undefined) return res.status(400).json({ error: "lat and lng are required" });

  const ride = await transact((db) => {
    const r = db.rides.find(r => r.id === req.params.id);
    if (!r) throw new Error("Ride not found");
    if (r.driverId !== req.user.id) throw new Error("Not your ride");
    r.driverLocation = { lat, lng, updatedAt: Date.now() };
    return r;
  }).catch(e => { throw e; });

  const io = req.app.get("io");
  io.to(`rider:${ride.riderId}`).emit("ride:location", { rideId: ride.id, lat, lng });
  res.json({ ok: true });
});

router.post("/:id/complete", requireAuth("driver"), async (req, res) => {
  const ride = await transact((db) => {
    const r = db.rides.find(r => r.id === req.params.id);
    if (!r) throw new Error("Ride not found");
    if (r.driverId !== req.user.id) throw new Error("Not your ride");
    r.status = "completed";
    r.completedAt = Date.now();
    return r;
  }).catch(e => { throw e; });
  req.app.get("io").to(`rider:${ride.riderId}`).emit("ride:completed", ride);
  res.json(ride);
});

module.exports = router;
