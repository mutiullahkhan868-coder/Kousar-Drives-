require("dotenv").config();
const express = require("express");
const http = require("http");
const cors = require("cors");
const path = require("path");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");
const { JWT_SECRET } = require("./middleware/auth");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.set("io", io);

app.use(cors());
app.use(express.json({ limit: "2mb" }));
// NOTE: driver documents (CNIC, license, vehicle papers) are intentionally NOT served as static
// files. They can only be viewed through /api/admin/drivers/:id/documents/:field, which requires
// a valid admin token - see routes/admin.js.

app.use("/api/auth", require("./routes/auth"));
app.use("/api/driver", require("./routes/driver"));
app.use("/api/rides", require("./routes/rides"));
app.use("/api/admin", require("./routes/admin"));

app.get("/api/health", (req, res) => res.json({ ok: true, time: Date.now() }));

// Serve the frontend (mobile web app) as static files
app.use(express.static(path.join(__dirname, "..", "frontend")));

/* ---------------- Socket.io: real-time ride offers & live location ---------------- */
io.on("connection", (socket) => {
  socket.on("join", ({ token }) => {
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      socket.join(`${decoded.role}:${decoded.id}`);
    } catch (e) {
      // ignore bad token; socket just won't be in any room
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Kousar Drives backend running on port ${PORT}`);
  console.log(`Admin login defaults to phone="admin" password="changeme123" unless overridden by env vars — change these before going live.`);
});
