// Simple JSON-file data store. Good enough for a single-city pilot.
// When you outgrow this (hundreds of concurrent rides), migrate to Postgres/MySQL.
const fs = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "db.json");

const DEFAULT_DB = {
  riders: [],
  drivers: [],
  rides: [],
  webauthnCredentials: [], // { driverId, credentialId, publicKey, counter }
  webauthnChallenges: {},  // { driverId: challenge }
  fareConfig: {
    // per-km min/max rates + base fare, tuned per vehicle type.
    // Admin can edit these from the admin panel. Base numbers are
    // placeholders reflecting rough fuel-cost + margin logic -
    // adjust to real Haripur fuel prices before going live.
    rickshaw: { baseFare: 30, minPerKm: 15, maxPerKm: 25, ccNote: "70-150cc bike rickshaws" },
    car:      { baseFare: 60, minPerKm: 25, maxPerKm: 40, ccNote: "1000-1300cc sedans/hatchbacks" },
    hiace:    { baseFare: 150, minPerKm: 45, maxPerKm: 70, ccNote: "2400-2700cc diesel vans" }
  }
};

function ensureDb() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2));
  }
}

function readDb() {
  ensureDb();
  const raw = fs.readFileSync(DB_FILE, "utf-8");
  return JSON.parse(raw);
}

function writeDb(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// Very simple write queue to avoid concurrent write corruption.
let writeLock = Promise.resolve();
function transact(fn) {
  writeLock = writeLock.then(() => {
    const db = readDb();
    const result = fn(db);
    writeDb(db);
    return result;
  });
  return writeLock;
}

module.exports = { readDb, transact };
