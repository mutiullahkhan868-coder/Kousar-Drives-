const jwt = require("jsonwebtoken");
const JWT_SECRET = process.env.JWT_SECRET || "change-this-secret-before-going-live";

function sign(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "30d" });
}

function requireAuth(role) {
  return (req, res, next) => {
    const header = req.headers.authorization || "";
    // Query-string token is only for cases like <a href> image links that can't set headers
    // (e.g. admin viewing a driver document). Prefer the Authorization header everywhere else.
    const token = header.startsWith("Bearer ") ? header.slice(7) : (req.query.token || null);
    if (!token) return res.status(401).json({ error: "Missing token" });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (role && decoded.role !== role) {
        return res.status(403).json({ error: "Wrong account type for this action" });
      }
      req.user = decoded;
      next();
    } catch (e) {
      return res.status(401).json({ error: "Invalid or expired token" });
    }
  };
}

module.exports = { sign, requireAuth, JWT_SECRET };
